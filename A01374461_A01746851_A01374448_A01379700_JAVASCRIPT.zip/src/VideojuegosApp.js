import React, { useState } from 'react';
import PropTypes from 'prop-types';

const VideojuegosApp = (props) => {

    const titulo = 'Mis videojuegos';
    const nombreVariable = props.nombre;

    let [cantidadDeVideojuuegos, setCantidadDeVideojuegos] = useState(0);
    const incrementaVideojuegos = (e) => {
        setCantidadDeVideojuegos(cantidadDeVideojuuegos + 1);
    }
    const quitarVideojuegos = (e) => {
        setCantidadDeVideojuegos(cantidadDeVideojuuegos - 1);
    }
    const reiniciarVideojuegos = (e) => {
        setCantidadDeVideojuegos(cantidadDeVideojuuegos = 0);
    }


    return (
        //Comentario UwU 
        <>
            {/*
            Comentario 
            */}
            <h1>{titulo}</h1>
            <h2> Bienvenidxs a la pagina de mis videojuegos UwU </h2>
            <p>Hola {nombreVariable}</p>
            <h2>Tengo {cantidadDeVideojuuegos} videojuegos!!!!</h2>
            <button onClick = { (e) => {incrementaVideojuegos(e)}}>Agregar videojuego </button>
            <button onClick = { (e) => {reiniciarVideojuegos(e)}}>Reinciar cantidad de videojuego </button>
            <button onClick = { (e) => {quitarVideojuegos(e)}}>Quitar videojuego </button>
        </>
    )
}

VideojuegosApp.propTypes = {
    nombre: PropTypes.string
}
VideojuegosApp.defaultProps = {
    nombre: "usuario"
}

export default VideojuegosApp;