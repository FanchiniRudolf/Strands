import React from 'react';


const ListaVideojuegosApp = () => {
    return(
        <>
        <ul>
            <li>Minecraft, Mojang Studios, 18 de noviembre de 2011<br></br> <img src="https://albolote.org/wp-content/uploads/2018/12/minecraft.jpg"></img> </li>
            <li>Grand Theft Auto V, Rockstar Games,17 de septiembre de 2013 <br></br><img src="https://static.wikia.nocookie.net/esgta/images/1/1b/Car%C3%A1tula_GTA_V.jpg"></img></li>
            <li>Dream Daddy: A Dad Dating Simulator,Game Grumps,20 de julio de 2017 <br></br><img src="https://todasgamers.com/wp-content/uploads/2017/07/dream-daddy.png"></img></li>
        </ul>
        </>
    )
}
export default ListaVideojuegosApp;