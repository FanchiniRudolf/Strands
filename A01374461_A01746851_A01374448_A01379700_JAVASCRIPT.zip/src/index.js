import React from 'react';
import ReactDOM from 'react-dom';
import VideojuegosApp from './VideojuegosApp';
import ListaVideojuegosApp from './ListaVideojuegosApp';
import './index.css';
import './ListaVideojuegosApp.css';

const divRoot = document.querySelector('#root');

ReactDOM.render(<VideojuegosApp nombre="Viviana"/>, divRoot);
//ReactDOM.render(<ListaVideojuegosApp/>, divRoot);